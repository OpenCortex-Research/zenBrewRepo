echo To update please uninstall and reinstall the package
